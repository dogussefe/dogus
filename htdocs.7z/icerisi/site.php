<style>

audio {
    width: 100%;
    max-width: 300px;
    margin-top: 20px;
}
::-webkit-scrollbar {
        display: none;
        visibility: hidden;
        opacity: 0
}

</style>
<audio controls loop autoplay style="margin-top: 20px;">
        <source src="music/dogussefe.mp3" type="audio/mp3">
        Tarayıcınız şarkıyı desteklemiyor.
    </audio>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <title>Doğuş Efe | dogussefe</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="format-detection" content="telephone=no">
    <meta name="format-detection" content="address=no">
    <meta name="author" content="Doğuş Efe">
    <meta name="description" content="Duvar manzaralı pencerede hayal kuruyorum.">
	<link rel="apple-touch-icon" sizes="144x144" href="admin/resimler/855979873-algos-teria.jpg">
	<link rel="apple-touch-icon" sizes="114x114" href="admin/resimler/855979873-algos-teria.jpg">
	<link rel="apple-touch-icon" sizes="72x72" href="admin/resimler/855979873-algos-teria.jpg">
	<link rel="apple-touch-icon" sizes="57x57" href="admin/resimler/855979873-algos-teria.jpg">
	<link rel="shortcut icon" href="admin/resimler/855979873-algos-teria.jpg" type="image/png">
	<link rel="stylesheet" type="text/css" href="assets/styles/style.css">
    <link rel="stylesheet" type="text/css" href="assets/demo/style-demo.css">
	<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Inter&family=Poppins:wght@500;700&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/58141539f3.js" crossorigin="anonymous"></script>
</head>
<body>

    <main class="main">
	    <!-- Header Image -->
		<div class="header-image">
			
		    <div class="header-image" style="background-image: url(admin/resimler/icon-192x192.png); background-repeat: repeat;"></div>
		</div>		
	    <div class="container gutter-top">
		  
<header class="header box">

			    <div class="header__left">

				    <div class="header__photo">

					    <img class="header__photo-img" src="admin/resimler/855979873-algos-teria.jpg" alt="Doğuş">

					</div>

					<div class="header__base-info">

					    <h4 class="title titl--h4"><span class="usernamecaptain">Doğuş Efe | dogussefe</span></h4>

						<div class="status"> Tüm İnternet Hizmetleri</div>

						<ul class="header__social">

							<li><a href="https://instagram.com/dogussefe"><i style="font-size: 22px; color:#fff" class="fa-brands fa-instagram"></i></a></li>

						</ul>

					</div>

				</div>

				<div class="header__right">

				    <ul class="header__contact">

						<li><span class="overhead">Konum</span>İzmir / Üçyol </li>

					</ul>
<ul class="header__contact">

						<li><span class="overhead">Namıdeğer</span>M.. </li>

					</ul>

					

				</div>

			</header>

		    <div style="justify-content: center;" class="row sticky-parent">

		        <div class="col-10 col-md-3 col-lg-10">
				    <div class="box box-content">

						<div class="mt-1">

						    <center><h2 class="title title--h2 text-align: center;">IP Adresiniz alındı.<br><br><span class="usernamecaptain"><?php

echo $_SERVER["REMOTE_ADDR"];

?></span></h2></center>
						</div>

						
								
							</div>

						</div>

					</div><br><br><br><br>

		        </div>

    </main>

	
   
    

	
	
    
</body>

</html>
